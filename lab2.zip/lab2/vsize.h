//
// Created by vad on 16/10/21.
// DI FCTUNL
//

#ifndef LAB2_VSIZE_H
#define LAB2_VSIZE_H

// Vector Size
#define VSIZE  100000

// when using threads use this thread group size by default
#define GROUPSIZE 1024

#endif //LAB2_VSIZE_H
